<?php $__env->startSection('content'); ?>

    
    <div x-show="activeTab === 'dataset'">
        <?php echo $__env->make('data-bayes.dataset', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div x-show="activeTab === 'initial_process'">
        <?php echo $__env->make('data-bayes.initial-process', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div x-show="activeTab === 'performance'">
        <?php echo $__env->make('data-bayes.performance', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

    
    <div x-show="activeTab === 'prediction'">
        <?php echo $__env->make('data-bayes.prediction', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.naive-bayes', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\KULIAH\Skripsi\Skripsi\resources\views/naive-bayes-page.blade.php ENDPATH**/ ?>