<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=instrument-sans:400,500,600" rel="stylesheet" />

        <!-- Styles / Scripts -->
        <?php if(file_exists(public_path('build/manifest.json')) || file_exists(public_path('hot'))): ?>
            <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php endif; ?>
</head>
<body>

    <header>
        <div class="nav-container">
            <h1>Naive Bayes Classifier</h1>
        </div>
    </header>

    <main class="content">
        <div class="login-container">
            <h2>Login</h2>
            <form action="<?php echo e(route('login')); ?>" method="POST">
                <?php echo csrf_field(); ?> <!-- Ini harus ada untuk keamanan CSRF -->

                <!-- Menampilkan pesan error validasi dari Fortify/Jetstream -->
                <?php if($errors->any()): ?>
                    <div class="bg-red-100 text-red-700 border border-red-400 rounded px-4 py-3 mb-4 text-center">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Menampilkan pesan status (misal: setelah password reset, dll.) -->
                <?php if(session('status')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('status')); ?>

                    </div>
                <?php endif; ?>

                <div class="mb-3">
                    <label for="name" class="form-label">Username</label>
                    <!-- Penting: name="username" jika Anda mengonfigurasi Fortify untuk username.
                         Jika tidak, gunakan name="email" dan ubah label menjadi "Email". -->
                    <input type="text" class="form-control form-control-lg" id="name" name="name" value="<?php echo e(old('name')); ?>" required autofocus autocomplete="name">
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control form-control-lg" id="password" name="password" required autocomplete="current-password">
                </div>

                <button type="submit" class="btn btn-primary">Masuk</button>

            </form>
        </div>
    </main>

    <?php if(Route::has('login')): ?>
        <div class="h-14.5 hidden lg:block"></div>
    <?php endif; ?>
</body>
</html>
<?php /**PATH D:\KULIAH\Skripsi\Skripsi\resources\views/welcome.blade.php ENDPATH**/ ?>