<?php

return [
    'failed' => 'Username atau password salah.',
    'password' => 'Password salah.',
    'throttle' => 'Terlalu banyak percobaan login. Coba lagi dalam :seconds detik.',
];
